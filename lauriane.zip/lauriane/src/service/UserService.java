package service;

import entities.Role;
import entities.User;
import repository.UserRepo;

public class UserService {
    private UserRepo userRepo=new UserRepo();

    public UserService() {
        if (userRepo.ifAcRp()==0) {
            User rp = new User(), ac=new User();
            // rp
            rp.setNomComplet("Rp");
            rp.setLogin("rp");
            rp.setPassword("passer");
            rp.setRole(Role.RP);
            // ac
            ac.setNomComplet("ac");
            ac.setLogin("ac");
            ac.setPassword("passer");
            ac.setRole(Role.AC);
        }
    }

    public User connexion(String login, String password){
        return userRepo.selectByLoginPassword(login, password);
    }
}
