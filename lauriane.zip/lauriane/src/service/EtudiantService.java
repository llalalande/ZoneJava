package service;

import entities.Etudiant;
import repository.EtudiantRepo;

public class EtudiantService {
    private EtudiantRepo etudiantRepo=new EtudiantRepo();

    public Etudiant enregistrer(Etudiant etudiant){
        etudiantRepo.insert(etudiant);
        return etudiantRepo.selectLast();
    }
    
    public Etudiant chercherParId(int id){
        return etudiantRepo.selectById(id);
    }
}
