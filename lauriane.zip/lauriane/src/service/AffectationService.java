package service;

import java.util.ArrayList;

import entities.Affectation;
import entities.Prof;
import repository.AffectationRepo;

public class AffectationService {
    private AffectationRepo affectationRepo=new AffectationRepo();

    public void enregistrer(Affectation affectation){
        affectationRepo.insert(affectation);
    }

    public ArrayList<Affectation> listerParProf(Prof prof){
        return affectationRepo.selectByProf(prof);
    }
}
