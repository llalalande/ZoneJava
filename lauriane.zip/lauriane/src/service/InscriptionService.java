package service;

import entities.Etudiant;
import entities.Inscription;
import repository.InscriptionRepo;

public class InscriptionService {
    private InscriptionRepo inscriptionRepo = new InscriptionRepo();

    public void enregistrer(Inscription inscription){
        inscriptionRepo.insert(inscription);
    }
    

    public int inscrireEtudiantSurAnnee(Etudiant etudiant){
        return inscriptionRepo.countInscriptionEtudiantAnnee(etudiant.getId());
    }

}
