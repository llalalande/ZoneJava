package service;

import java.util.ArrayList;

import entities.Classe;
import repository.ClasseRepo;

public class ClasseService {
    private ClasseRepo classeRepo=new ClasseRepo();

    public void enregistrer(Classe classe){
        classeRepo.insert(classe);
    }

    public Classe chercherParId(int id){
        return classeRepo.selectById(id);
    }

    public ArrayList<Classe> lister(){
        return classeRepo.selectAll();
    }
}
