package service;

import java.util.ArrayList;

import entities.Prof;
import repository.ProfRepo;

public class ProfService {
    private ProfRepo profRepo=new ProfRepo();
    
    public void enregistrer(Prof prof){
        profRepo.insert(prof);
    }
    
    public Prof chercherParId(int id){
        return profRepo.selectById(id);
    }
    
    public ArrayList<Prof> lister(){
        return profRepo.selectAll();
    }
}
