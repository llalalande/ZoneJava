package service;

import entities.Annee;
import repository.AnneeRepo;

public class AnneeService {
    private AnneeRepo anneeRepo=new AnneeRepo();

    public Annee currentYear(){
        return anneeRepo.selectActuel();
    }
}
