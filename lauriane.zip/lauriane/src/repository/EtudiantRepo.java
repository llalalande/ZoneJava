package repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import entities.Role;
import entities.Etudiant;

public class EtudiantRepo {
    // Déclaration des informations de connexion à la base de données
    private static final String URL = "jdbc:mysql://localhost/java";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";

  
    public void insert(Etudiant etudiant) {
        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO user (matricule, nomComplet, tuteur, role) VALUES(?, ?, ?, ?)")) {
            
            // Set the parameters of the prepared statement
            preparedStatement.setString(1, etudiant.getMatricule());
            preparedStatement.setString(2, etudiant.getNomComplet());
            preparedStatement.setString(3, etudiant.getTuteur());
            preparedStatement.setString(4, etudiant.getRole().name());

            // Execute the insert statement
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Etudiant selectById(int id) {
        Etudiant etudiant=null;

        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM user WHERE id=?")) {
            
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                int id_etudiant = resultSet.getInt("id");
                String nomComplet = resultSet.getString("nomComplet");
                String tuteur = resultSet.getString("tuteur");
                String matricule = resultSet.getString("matricule");
                Role role=null;
                
                switch (resultSet.getString("role")) {
                    case "AC":
                        role = Role.AC;
                        break;
                
                    case "RP":
                        role = Role.RP;
                        break;
                
                    case "PROF":
                        role = Role.PROF;
                        break;
                        
                    default:
                        role = Role.ETUDIANT;
                        break;
                }
                

                etudiant = new Etudiant();
                etudiant.setId(id_etudiant);
                etudiant.setMatricule(matricule);
                etudiant.setNomComplet(nomComplet);
                etudiant.setTuteur(tuteur);
                etudiant.setRole(role);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return etudiant;
    }

    public Etudiant selectLast() {
        Etudiant etudiant=null;

        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT *, MAX(id) as maxid FROM user")) {
            
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                int id_etudiant = resultSet.getInt("id");
                String nomComplet = resultSet.getString("nomComplet");
                String tuteur = resultSet.getString("tuteur");
                String matricule = resultSet.getString("matricule");
                Role role=null;
                
                switch (resultSet.getString("role")) {
                    case "AC":
                        role = Role.AC;
                        break;
                
                    case "RP":
                        role = Role.RP;
                        break;
                
                    case "PROF":
                        role = Role.PROF;
                        break;
                        
                    default:
                        role = Role.ETUDIANT;
                        break;
                }
                

                etudiant = new Etudiant();
                etudiant.setId(id_etudiant);
                etudiant.setMatricule(matricule);
                etudiant.setNomComplet(nomComplet);
                etudiant.setTuteur(tuteur);
                etudiant.setRole(role);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return etudiant;
    }

}
