package repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entities.Affectation;
import entities.Prof;

public class AffectationRepo {
    private static final String URL = "jdbc:mysql://localhost/java";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
    private static ClasseRepo classeRepo=new ClasseRepo();
  
    public void insert(Affectation affectation) {
        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO affectation (prof, classe) VALUES (?, ?)")) {
            
            // Set the parameters of the prepared statement
            preparedStatement.setInt(1, affectation.getProf().getId());
            preparedStatement.setInt(2, affectation.getClasse().getId());

            // Execute the insert statement
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Affectation> selectByProf(Prof prof) {
        ArrayList<Affectation> affectations=new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM affectation WHERE prof=?")) {
            
            // Set the parameters of the prepared statement
            preparedStatement.setInt(1, prof.getId());
            
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("id");

                Affectation affectation = new Affectation(id, classeRepo.selectById(resultSet.getInt("classe")), prof);
                // 
                affectations.add(affectation);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return affectations;
    }

}
