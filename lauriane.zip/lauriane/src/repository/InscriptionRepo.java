package repository;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entities.Annee;
import entities.Classe;
import entities.Etudiant;
import entities.Inscription;

public class InscriptionRepo {
    // Déclaration des informations de connexion à la base de données
    private static final String URL = "jdbc:mysql://localhost/java";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
    private static final ClasseRepo classeRepo = new ClasseRepo();
    private static final EtudiantRepo etudiantRepo = new EtudiantRepo();

  
    public void insert(Inscription inscription) {
        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO inscription (date, montant, annee, etudiant, classe ,type) VALUES(? , ?, ?, ?, ?)")) {
            
            // Set the parameters of the prepared statement
            preparedStatement.setDate(1, inscription.getDate());
            preparedStatement.setDouble(2, inscription.getMontant());
            preparedStatement.setInt(3, inscription.getannee().getId());
            preparedStatement.setInt(4, inscription.getEtudiant().getId());
            preparedStatement.setInt(5, inscription.getClasse().getId());
            preparedStatement.setInt(5, inscription.getType());

            // Execute the insert statement
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public int countInscriptionEtudiantAnnee(int id) {
        int inscriptiption=0;

        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT COUNT(i.id) as insc FROM inscription i, annee a, user e WHERE i.annee=a.id and i.etudiant=e.id and a.etat=1")) {
            
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                inscriptiption = resultSet.getInt("insc");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return inscriptiption;
    }

    public ArrayList<Inscription> selectByAnnee() {
        ArrayList<Inscription> inscriptions=new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT i.* FROM inscription i, annee a, user e WHERE i.annee=a.id and i.etudiant=e.id and a.etat=1")) {
                
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                int id = resultSet.getInt("id");
                int type = resultSet.getInt("type");
                Date date = resultSet.getDate("date");
                Double montant = resultSet.getDouble("montant");
                Annee annee = null;
                Classe classe = classeRepo.selectById(resultSet.getInt("classe"));
                Etudiant etudiant = etudiantRepo.selectById(resultSet.getInt("etudiant"));

                Inscription inscription = new Inscription();
                inscription.setId(id);
                inscription.setDate(date);
                inscription.setMontant(montant);
                inscription.setClasse(classe);
                inscription.setMontant(type);
                inscription.setType(type);
                inscription.setEtudiant(etudiant);
                inscription.setannee(annee);

                inscriptions.add(inscription);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return inscriptions;
    }

    
}
