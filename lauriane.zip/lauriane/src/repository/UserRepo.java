package repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import entities.Role;
import entities.User;

public class UserRepo {
    // Déclaration des informations de connexion à la base de données
    private static final String URL = "jdbc:mysql://localhost/java";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";

    public void insert(User user) {
        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO user (nomComplet, login, password, role) VALUES(?, ?, ?, ?)")) {
            
            // Set the parameters of the prepared statement
            preparedStatement.setString(1, user.getNomComplet());
            preparedStatement.setString(2, user.getLogin());
            preparedStatement.setString(3, user.getPassword());
            preparedStatement.setString(4, user.getRole().name());

            // Execute the insert statement
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public User selectByLoginPassword(String login, String password) {
        User user = null;

        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM user WHERE login=? and password=?")) {
                
            preparedStatement.setString(1, login);
            preparedStatement.setString(2, password);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                int id = resultSet.getInt("id");
                String nomComplet = resultSet.getString("nomComplet");
                Role role=null;
                
                switch (resultSet.getString("role")) {
                    case "AC":
                        role = Role.AC;
                        break;
                
                    case "RP":
                        role = Role.RP;
                        break;
                
                    case "PROF":
                        role = Role.PROF;
                        break;
                        
                    default:
                        role = Role.ETUDIANT;
                        break;
                }
                
                user = new User();
                user.setId(id);
                user.setNomComplet(nomComplet);
                user.setLogin(login);
                user.setPassword(password);
                user.setRole(role);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return user;
    }

    public int ifAcRp() {
        int acRp = 0;

        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT COUNT(*) as acrp FROM user")) {
                
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                acRp = resultSet.getInt("acrp");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return acRp;
    }

}
