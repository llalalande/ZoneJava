package repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entities.Prof;
import entities.Role;

public class ProfRepo {
    // Déclaration des informations de connexion à la base de données
    private static final String URL = "jdbc:mysql://localhost/java";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";

  
    public void insert(Prof prof) {
        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO user (nci, nomComplet, grade, role) VALUES(?, ?, ?, ?)")) {
            
            // Set the parameters of the prepared statement
            preparedStatement.setString(1, prof.getNci());
            preparedStatement.setString(2, prof.getNomComplet());
            preparedStatement.setString(3, prof.getGrade());
            preparedStatement.setString(4, prof.getRole().name());

            // Execute the insert statement
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Prof> selectAll() {
        ArrayList<Prof> profs=new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM user WHERE role='PROF'")) {
            
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int id_prof = resultSet.getInt("id");
                String nomComplet = resultSet.getString("nomComplet");
                String grade = resultSet.getString("grade");
                String nci = resultSet.getString("nci");
                Role role=null;
                
                switch (resultSet.getString("role")) {
                    case "AC":
                        role = Role.AC;
                        break;
                
                    case "RP":
                        role = Role.RP;
                        break;
                
                    case "PROF":
                        role = Role.PROF;
                        break;
                        
                    default:
                        role = Role.ETUDIANT;
                        break;
                }
                

                Prof prof = new Prof();
                prof.setId(id_prof);
                prof.setGrade(grade);
                prof.setNomComplet(nomComplet);
                prof.setNci(nci);
                prof.setRole(role);

                profs.add(prof);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return profs;
    }

    public Prof selectById(int id) {
        Prof prof=null;

        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM user WHERE id=?")) {
            
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                int id_prof = resultSet.getInt("id");
                String nomComplet = resultSet.getString("nomComplet");
                String grade = resultSet.getString("grade");
                String nci = resultSet.getString("nci");
                Role role=null;
                
                switch (resultSet.getString("role")) {
                    case "AC":
                        role = Role.AC;
                        break;
                
                    case "RP":
                        role = Role.RP;
                        break;
                
                    case "PROF":
                        role = Role.PROF;
                        break;
                        
                    default:
                        role = Role.ETUDIANT;
                        break;
                }
                

                prof = new Prof();
                prof.setId(id_prof);
                prof.setGrade(grade);
                prof.setNomComplet(nomComplet);
                prof.setNci(nci);
                prof.setRole(role);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return prof;
    }

}
