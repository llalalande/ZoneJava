package repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import entities.Annee;

public class AnneeRepo {
    // Déclaration des informations de connexion à la base de données
    private static final String URL = "jdbc:mysql://localhost/java";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
    

    public Annee selectActuel() {
        Annee annee = null;

        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM annee WHERE etat=1")) {
            
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                int id = resultSet.getInt("id");

                annee = new Annee(id,resultSet.getString("libelle"), resultSet.getInt("etat"));
                // 
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return annee;
    }
}
