package repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entities.Classe;
import entities.Filiere;
import entities.Niveau;

public class ClasseRepo {
    // Déclaration des informations de connexion à la base de données
    private static final String URL = "jdbc:mysql://localhost/java";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";

    
    public void insert(Classe classe) {
        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO classe (libelle, filiere, niveau) VALUES (?, ?, ?)")) {
            
            // Set the parameters of the prepared statement
            preparedStatement.setString(1, classe.getLibelle());
            preparedStatement.setString(2, classe.getFiliere().name());
            preparedStatement.setString(3, classe.getNiveau().name());

            // Execute the insert statement
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Classe> selectAll() {
        ArrayList<Classe> classes=new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM classe")) {
            
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String libelle = resultSet.getString("libelle");
                Filiere filiere = null;
                Niveau niveau = null;

                switch (resultSet.getString("filiere")) {
                    case "GLRS":
                        filiere = Filiere.GLRS;
                        break;
                
                    case "CPD":
                        filiere = Filiere.CPD;
                        break;
                        
                    default:
                        filiere = Filiere.IAGE;
                        break;
                }
                
                switch (resultSet.getString("niveau")) {
                    case "L1":
                        niveau = Niveau.L1;
                        break;
                
                    case "L2":
                        niveau = Niveau.L2;
                        break;
                        
                    default:
                        niveau = Niveau.L3;
                        break;
                }
                

                Classe classe = new Classe();
                classe.setId(id);
                classe.setLibelle(libelle);
                classe.setFiliere(filiere);
                classe.setNiveau(niveau);
                // 
                classes.add(classe);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return classes;
    }

    public Classe selectById(int id_classe) {
        Classe classe = null;
        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM classe WHERE id=?")) {
            
            preparedStatement.setInt(1, id_classe);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String libelle = resultSet.getString("libelle");
                Filiere filiere = null;
                Niveau niveau = null;

                switch (resultSet.getString("filiere")) {
                    case "GLRS":
                        filiere = Filiere.GLRS;
                        break;
                
                    case "CPD":
                        filiere = Filiere.CPD;
                        break;
                        
                    default:
                        filiere = Filiere.IAGE;
                        break;
                }
                
                switch (resultSet.getString("niveau")) {
                    case "L1":
                        niveau = Niveau.L1;
                        break;
                
                    case "L2":
                        niveau = Niveau.L2;
                        break;
                        
                    default:
                        niveau = Niveau.L3;
                        break;
                }
                

                classe = new Classe();
                classe.setId(id);
                classe.setLibelle(libelle);
                classe.setFiliere(filiere);
                classe.setNiveau(niveau);
                // 
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return classe;
    }

}
