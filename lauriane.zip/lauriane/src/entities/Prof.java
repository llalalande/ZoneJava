package entities;

import java.util.ArrayList;

public class Prof extends User {
    private String nci;
    private String grade;
    private ArrayList<Affectation> affectations;


    public String getNci() {
        return nci;
    }
    public void setNci(String nci) {
        this.nci = nci;
    }
    public String getGrade() {
        return grade;
    }
    public void setGrade(String grade) {
        this.grade = grade;
    }
    public ArrayList<Affectation> getAffectations() {
        return affectations;
    }
    public void addAffectations(Affectation affectation) {
        this.affectations.add(affectation);
    }
}
