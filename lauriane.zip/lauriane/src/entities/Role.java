package entities;

public enum Role {
    AC, RP, PROF, ETUDIANT
}
