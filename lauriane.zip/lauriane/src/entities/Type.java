package entities;

public enum Type {
    INSCRIPTION, REINSCRIPTION
}
