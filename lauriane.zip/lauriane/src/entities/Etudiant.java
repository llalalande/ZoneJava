package entities;

import java.util.ArrayList;

public class Etudiant extends User {
    private String matricule;
    private String tuteur;
    private ArrayList<Inscription> inscriptions;

    public ArrayList<Inscription> getInscriptions() {
        return inscriptions;
    }
    public void setInscriptions(ArrayList<Inscription> inscriptions) {
        this.inscriptions = inscriptions;
    }
    public String getMatricule() {
        return matricule;
    }
    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }
    public String getTuteur() {
        return tuteur;
    }
    public void setTuteur(String tuteur) {
        this.tuteur = tuteur;
    }
}
