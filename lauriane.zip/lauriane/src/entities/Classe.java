package entities;

import java.util.ArrayList;

public class Classe {
    private int id;
    private String libelle;
    private Niveau niveau;
    private Filiere filiere;
    private ArrayList<Affectation> affectations;
    private ArrayList<Inscription> inscriptions;
    

    public ArrayList<Inscription> getInscriptions() {
        return inscriptions;
    }


    public void setInscriptions(ArrayList<Inscription> inscriptions) {
        this.inscriptions = inscriptions;
    }


    public Classe() {
    }

    
    public Classe(int id, String libelle, Niveau niveau, Filiere filiere) {
        this.id = id;
        this.libelle = libelle;
        this.niveau = niveau;
        this.filiere = filiere;
    }

    public Classe(String libelle, Niveau niveau, Filiere filiere) {
        this.libelle = libelle;
        this.niveau = niveau;
        this.filiere = filiere;
    }


    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getLibelle() {
        return libelle;
    }
    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }
    public Niveau getNiveau() {
        return niveau;
    }
    public void setNiveau(Niveau niveau) {
        this.niveau = niveau;
    }
    public Filiere getFiliere() {
        return filiere;
    }
    public void setFiliere(Filiere filiere) {
        this.filiere = filiere;
    }
    public ArrayList<Affectation> getAffectations() {
        return affectations;
    }
    public void addAffectations(Affectation affectation) {
        this.affectations.add(affectation);
    }

}
