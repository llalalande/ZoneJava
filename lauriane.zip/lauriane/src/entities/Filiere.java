package entities;

public enum Filiere {
    IAGE,GLRS,CPD
}
