import java.sql.Date;
import java.util.Scanner;

import entities.Affectation;
import entities.Annee;
import entities.Classe;
import entities.Etudiant;
import entities.Filiere;
import entities.Inscription;
import entities.Niveau;
import entities.Prof;
import entities.Role;
import entities.User;
import service.AffectationService;
import service.AnneeService;
import service.ClasseService;
import service.EtudiantService;
import service.InscriptionService;
import service.ProfService;
import service.UserService;

public class App {
    private static Scanner scanner=new Scanner(System.in);
    
    public static void main(String[] args) throws Exception {
        UserService userService=new UserService();
        EtudiantService etudiantService=new EtudiantService();
        ProfService profService=new ProfService();
        AnneeService anneeService=new AnneeService();
        ClasseService classeService=new ClasseService();
        InscriptionService inscriptionService=new InscriptionService();
        AffectationService affectationService=new AffectationService();

        User user = connexion(userService);

        int choix;
        Classe classe;
        Prof prof;
        Etudiant etudiant;
        Inscription inscription;
        Filiere filiere=null;
        Niveau niveau=null;
        Annee annee = anneeService.currentYear();
        do {
            System.out.println("==== MENU ===\n");
            System.out.println("1- Creer une classe");
            System.out.println("2- Lister les classes");
            System.out.println("3- Creer un professeur");
            System.out.println("4- Affecter une classe a un professeur");
            System.out.println("5- Lister les professeurs");
            System.out.println("6- Lister les classes d'un professeur");
            System.out.println("7- Faire une inscription");
            System.out.println("8- Faire une reinscription");
            System.out.println("0- QUITTER");

            choix = scanner.nextInt();
            switch (choix) {
                case 1:
                    if (user.getRole().name().equals(Role.RP.name())) {
                        
                        System.out.println("Entrer le libelle de la classe: ");
                        String libelle = scanner.nextLine();
                        System.out.println("--FILIERE--");
                        System.out.println("1- GLRS");
                        System.out.println("2- IAGE");
                        System.out.println("3- CPD");
                        System.out.println("Choisissez: ");
                        int fil = scanner.nextInt();
                        switch (fil) {
                            case 1:
                                filiere = Filiere.GLRS;
                                break;
                            case 2:
                                filiere = Filiere.IAGE;
                                break;
                            case 3:
                                filiere = Filiere.CPD;
                                break;
                        
                            default:
                                filiere=null;
                                break;
                        }
                        
                        System.out.println("--NIVEAU--");
                        System.out.println("1- L1");
                        System.out.println("2- L2");
                        System.out.println("3- L3");
                        System.out.println("Choisissez: ");
                        int niv = scanner.nextInt();
                        switch (niv) {
                            case 1:
                                niveau = Niveau.L1;
                                break;
                            case 2:
                                niveau = Niveau.L2;
                                break;
                            case 3:
                                niveau = Niveau.L3;
                                break;
                        
                            default:
                                filiere=null;
                                break;
                        }
                        
                        classe = new Classe();
                        classe.setFiliere(filiere);
                        classe.setLibelle(libelle);
                        classe.setNiveau(niveau);
                        classeService.enregistrer(classe);
                    }else{
                        System.out.println("++ ACCES REFUSE ++");
                    }
                    break;
            
                case 2:
                    if (user.getRole().name().equals(Role.RP.name())) {
                        for (Classe cl : classeService.lister()) {
                            System.out.println(cl);
                        }
                    }else{
                        System.out.println("++ ACCES REFUSE ++");
                    }
                    break;
                case 3:
                    if (user.getRole().name().equals(Role.RP.name())) {
                        System.out.println("Entre le nci : ");
                        String nci=scanner.nextLine();
                        System.out.println("Entre le nom complet : ");
                        String nomC=scanner.nextLine();
                        System.out.println("Entre le grade : ");
                        String grade=scanner.nextLine();
                        prof = new Prof();
                        prof.setGrade(grade);
                        prof.setNci(nci);
                        prof.setNomComplet(nomC);
                        prof.setRole(Role.PROF);
                        profService.enregistrer(prof);
                    }else{
                        System.out.println("++ ACCES REFUSE ++");
                    }
                    break;
                
                case 4:
                    if (user.getRole().name().equals(Role.RP.name())) {
                        System.out.println("Entrer l'id du prof");
                        prof=profService.chercherParId(scanner.nextInt());
                        if (prof!=null) {
                            System.out.println("Entrer l'id de la classe");
                            classe = classeService.chercherParId(scanner.nextInt());
                            if (classe!=null) {
                                affectationService.enregistrer(new Affectation(0, classe, prof));
                            }
                        }
                    }else{
                        System.out.println("++ ACCES REFUSE ++");
                    }
                    break;
                
                case 5:
                    if (user.getRole().name().equals(Role.RP.name())) {
                        for (Prof prf : profService.lister()) {
                            System.out.println(prf);
                        }
                    }else{
                        System.out.println("++ ACCES REFUSE ++");
                    }
                    break;

                case 6:
                    if (user.getRole().name().equals(Role.RP.name())) {
                        System.out.println("Entrer l'id du prof");
                        prof=profService.chercherParId(scanner.nextInt());
                        if (prof!=null) {
                            for (Affectation affec : affectationService.listerParProf(prof)) {
                                System.out.println(affec.getClasse());
                            }
                        }
                    }else{
                        System.out.println("++ ACCES REFUSE ++");
                    }
                    break;

                case 7:
                    if (user.getRole().name().equals(Role.AC.name())) {
                        System.out.println("Entrer le matricule");
                        String matricule=scanner.nextLine();
                        System.out.println("Entrer le nom complet de l'etudiant");
                        String nomComplet=scanner.nextLine();
                        System.out.println("Entrer le tuteur l'etudiant");
                        String tuteur=scanner.nextLine();
                        System.out.println("Entrer la date");
                        String date=scanner.nextLine();
                        System.out.println("Entrer le montant");
                        Double montant=scanner.nextDouble();
                        System.out.println("Entrer l'id de la classe");
                        classe=classeService.chercherParId(scanner.nextInt());
                        if (classe!=null) {
                        etudiant = new Etudiant();
                        etudiant.setMatricule(matricule);
                        etudiant.setNomComplet(nomComplet);
                        etudiant.setRole(Role.ETUDIANT);
                        etudiant.setTuteur(tuteur);
                        etudiant = etudiantService.enregistrer(etudiant);
                        // 
                        inscription = new Inscription();
                        inscription.setType(1);
                        inscription.setannee(annee);
                        inscription.setClasse(classe);
                        inscription.setMontant(montant);
                        inscription.setEtudiant(etudiant);
                        inscription.setDate(Date.valueOf(date));
                        inscriptionService.enregistrer(inscription);
                    }
                    }else{
                        System.out.println("++ ACCES REFUSE ++");
                    }
                    break;
                
                case 8:
                    if (user.getRole().name().equals(Role.AC.name())) {
                        System.out.println("Entrer l'id de l'etudiant");
                        etudiant = etudiantService.chercherParId(scanner.nextInt());
                        if (etudiant!=null) {
                            if (inscriptionService.inscrireEtudiantSurAnnee(etudiant)==0) {
                                System.out.println("Entrer la date");
                                String date_=scanner.nextLine();
                                System.out.println("Entrer le montant");
                                Double montant_=scanner.nextDouble();
                                System.out.println("Entrer l'id de la classe");
                                classe=classeService.chercherParId(scanner.nextInt());
                                if (classe!=null) {
                                    inscription = new Inscription();
                                    inscription.setType(2);
                                    inscription.setannee(annee);
                                    inscription.setClasse(classe);
                                    inscription.setMontant(montant_);
                                    inscription.setEtudiant(etudiant);
                                    inscription.setDate(Date.valueOf(date_));
                                    inscriptionService.enregistrer(inscription);
                                }
                            }
                        }
                    }else{
                        System.out.println("++ ACCES REFUSE ++");
                    } 
                    break;
                
                default:
                    
                    break;
            }
        } while (choix!=0);


    }

    public static User connexion(UserService userService){
        User user=null;
        String login;
        String password;
        while (user==null) {
            System.out.println("**CONNEXION**\n\n");
            System.out.println("Login: ");
            login = scanner.nextLine();
            System.out.println("mot de passe: ");
            password = scanner.nextLine();
            user = userService.connexion(login, password);
            if (user==null) {
                System.out.println("\n--- LOGIN OU MOT DE PASSE INCORRET ---\n");
            }
        }
        return user;
    }
}
